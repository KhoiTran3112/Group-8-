module.exports = {
    DB: "mongodb+srv://tamtran:tam@tran@2020@dgnl-hcmue.8yayn.mongodb.net/Group_08?retryWrites=true&w=majority"
}